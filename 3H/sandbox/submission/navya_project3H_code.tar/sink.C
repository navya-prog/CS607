#include "sink.h"

void Sink::SetInput(Image *img)
{
    this->img1 = img;
}

void Sink::SetInput2(Image *img)
{
    this->img2 = img;
}
