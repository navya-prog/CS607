#include "source.h"

Image *Source::GetOutput()
{
    return &this->img;
}
